INSERT INTO `personal information` (`id`, `Name`, `Personal Type`) VALUES (123001, 'Tom', 'community manager');
INSERT INTO `personal information` (`id`, `Name`, `Personal Type`) VALUES (123002, 'Jiom', 'community volunteer');
INSERT INTO `personal information` (`id`, `Name`, `Personal Type`) VALUES (123003, 'Luse', 'community activity manager');
INSERT INTO `personal information` (`id`, `Name`, `Personal Type`) VALUES (123004, 'Tina', 'community security');
