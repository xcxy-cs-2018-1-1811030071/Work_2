INSERT INTO `community education resources` (`id`, `ResourceId`, `Style`) VALUES ('200001', '1', 'vocational skills');
INSERT INTO `community education resources` (`id`, `ResourceId`, `Style`) VALUES ('200002', '2', 'literary leisure');
INSERT INTO `community education resources` (`id`, `ResourceId`, `Style`) VALUES ('200003', '3', 'digital books');
INSERT INTO `community education resources` (`id`, `ResourceId`, `Style`) VALUES ('200004', '4', 'film and television');
INSERT INTO `community education resources` (`id`, `ResourceId`, `Style`) VALUES ('200005', '5', 'animated show');
