INSERT INTO `community education activities` (`id`, `Activiteid`, `Style`) VALUES (100001, 1, 'photography show');
INSERT INTO `community education activities` (`id`, `Activiteid`, `Style`) VALUES (100002, 2, 'recital contest');
INSERT INTO `community education activities` (`id`, `Activiteid`, `Style`) VALUES (100003, 3, 'poetry contest');
INSERT INTO `community education activities` (`id`, `Activiteid`, `Style`) VALUES (100004, 4, 'singing contest');
INSERT INTO `community education activities` (`id`, `Activiteid`, `Style`) VALUES (100005, 5, 'tradition culture knowledge contest');
